﻿using System;
using System.IO;
using System.Linq;

namespace ConsoleAppCommands
{
    class Program
    {
        static void Main(string[] args)
        {
            while (true)
            {
                Console.WriteLine("Available Commands:");
                Console.WriteLine("1. File Copy");
                Console.WriteLine("2. File Delete");
                Console.WriteLine("3. Query Folder Files");
                Console.WriteLine("4. Create Folder");
                Console.WriteLine("5. Download File");
                Console.WriteLine("6. Wait");
                Console.WriteLine("7. Conditional Count Rows File");
                Console.WriteLine("8. Exit");
                Console.Write("Enter the command number: ");

                if (int.TryParse(Console.ReadLine(), out int choice))
                {
                    switch (choice)
                    {
                        case 1:
                            Console.Write("Enter Source File Path: ");
                            string sourceFilePath = Console.ReadLine();
                            Console.Write("Enter Destination File Path: ");
                            string destFilePath = Console.ReadLine();
                            File.Copy(sourceFilePath, destFilePath, true);
                            Console.WriteLine("File copied successfully!");
                            break;

                        case 2:
                            Console.Write("Enter File Path to Delete: ");
                            string filePathToDelete = Console.ReadLine();
                            File.Delete(filePathToDelete);
                            Console.WriteLine("File deleted successfully!");
                            break;

                        case 3:
                            Console.Write("Enter Folder Path: ");
                            string folderPath = Console.ReadLine();
                            string[] filesInFolder = Directory.GetFiles(folderPath);
                            Console.WriteLine("Files in Folder:");
                            foreach (string file in filesInFolder)
                            {
                                Console.WriteLine(file);
                            }
                            break;

                        case 4:
                            Console.Write("Enter Folder Path: ");
                            string parentFolderPath = Console.ReadLine();
                            Console.Write("Enter New Folder Name: ");
                            string newFolderName = Console.ReadLine();
                            Directory.CreateDirectory(Path.Combine(parentFolderPath, newFolderName));
                            Console.WriteLine("Folder created successfully!");
                            break;

                        case 5:
                            Console.Write("Enter Source URL: ");
                            string sourceUrl = Console.ReadLine();
                            Console.Write("Enter Output File Path: ");
                            string outputFile = Console.ReadLine();
                            using (var client = new System.Net.WebClient())
                            {
                                client.DownloadFile(sourceUrl, outputFile);
                            }
                            Console.WriteLine("File downloaded successfully!");
                            break;

                        case 6:
                            Console.Write("Enter Wait Time in Seconds: ");
                            if (int.TryParse(Console.ReadLine(), out int waitTime))
                            {
                                System.Threading.Thread.Sleep(waitTime * 1000);
                            }
                            else
                            {
                                Console.WriteLine("Invalid input for wait time.");
                            }
                            break;

                        case 7:
                            Console.Write("Enter Source File Path: ");
                            string sourceFile = Console.ReadLine();
                            Console.Write("Enter String to Search: ");
                            string searchString = Console.ReadLine();
                            int count = File.ReadLines(sourceFile).Count(line => line.Contains(searchString));
                            Console.WriteLine($"Count of rows containing '{searchString}': {count}");
                            break;

                        case 8:
                            Environment.Exit(0);
                            break;

                        default:
                            Console.WriteLine("Invalid command number.");
                            break;
                    }
                }
                else
                {
                    Console.WriteLine("Invalid input. Please enter a valid command number.");
                }

                Console.WriteLine(); 
            }
        }
    }
}